﻿// Laura Jones 21/11/21 Channel Processing
//This holds the main window function
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using OxyPlot;
using Ookii.Dialogs.Wpf;
using Microsoft.Win32;


namespace AMGChannelTesting
{
    class UtilFunctions
    {
        public static double[] LoadInput(string filepath)
        //read text file from filepath input and return array of doubles
        {
            Console.WriteLine("loading input");
            // read in text file as string - ignore new lines for now and read in entire file
            string inputString = System.IO.File.ReadAllText(filepath);
            Console.WriteLine(inputString);  // FOR TEST ONLY

            //split string by commas as csv
            string[] inputXString = inputString.Split(',');

            //now convert to array of doubles - create string array, populate list of doubles, create array of doubles
            List<double> DList = new List<double>();
            double dbXval;
            foreach (var Xval in inputXString)
            {
                Xval.Trim(' ');
                //Console.WriteLine($"{Xval}"); //TEST ONLY - print out each read value should be X followed by numbers only 
                dbXval = ConvertStrToDouble(Xval); //will be 0 for 'X'
                DList.Add(dbXval);
            }
            double[] XVals = DList.ToArray();

            return XVals;
        }
        //Create the filepath string to 
        public static string BuildFilePath(string filename)
        {
            //build filepath from filename with extention
            StringBuilder sb = new StringBuilder();
            sb.Append(@"C:\Users\Laura.Jones\source\repos\ChannelTestingSystem\ChannelTestingSystem\");
            sb.Append(filename);
            string FullFilePath = sb.ToString();
            return FullFilePath;
        }

        //Process the X values read by LoadInput, returns the B values as a double array
        public static double[] ProcessB(double[] Xvals, Int32 ArrLen, double m, double c)
        {
            double[] BVals = new double[ArrLen]; //create array same length as input array
            List<double> BList = new List<double>();
            double dbB;
            for(int i = 1; i < ArrLen; i++)
            {
                dbB = (1 / Xvals[i]) + (m * Xvals[i]) + (c);
                //Console.WriteLine($"{dbB}"); //TEST ONLY - print out each read value should be X followed by numbers only 
                BList.Add(dbB);
            }
            double[] Bvals = BList.ToArray();
            return Bvals;
        }
        //Calculate b from B
        public static double CalcB(double[] Bvals, Int32 ArrLen)
        {
            double Sum =0;
            //sum all values
            foreach (double B in Bvals)
            {
                Sum += B;
            }
            double b = Sum / (Convert.ToDouble(ArrLen)-1); //mean average, array length is 1 too long
            return b;
        }
        //Calculate C Values from X and b
        public static double[] GetCVals(double[] Xvals, double Valb, Int32 ArrLen)
        {
            List<double> CList = new List<double>();
            double dbC;
            for (int i = 0; i < ArrLen; i++)
            {
                dbC = Xvals[i] + Valb;
                Console.WriteLine($"{dbC}"); //TEST ONLY - print out each read value should be X followed by numbers only 
                CList.Add(dbC);
            }
            double[] Cvals = CList.ToArray();
            return Cvals;
        }
   
       

        //Util to convert string to double
        public static double ConvertStrToDouble(string textVal)
        {
            //converts input to double, return 0 if exception is caught (eg if X passed rather than number)
            double doubleVal = 0;
            try
            {
                //covert string input into double precision 
                doubleVal = Convert.ToDouble(textVal);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message.ToString(), "Error");
            }
            return doubleVal;
        }

        public static string ShowFolderBrowser()
        {
            //open a file browsing window
            var dialog = new Microsoft.Win32.OpenFileDialog();
            var newDestination = Environment.CurrentDirectory;
            string fullPath = "channels.txt"; 
            if (dialog.ShowDialog() == true)
            {
                fullPath = dialog.FileName;
                
            }
            return fullPath;

        }

    }
}
